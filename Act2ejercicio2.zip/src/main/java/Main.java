import java.util.Scanner;
public class Main {
  public static void main (String[] args){
    //DEFINICION DE VARIABLES
    float FRH, CLS;
    Scanner teclado = new Scanner (System.in);
    //DATOS DE ENTRADA
    System.out.println("Digite grado Farenheit");
    FRH = teclado.nextFloat();
    //PROCESAMIENTO
    CLS = (FRH-32)*5/9;
    //DATOS DE SALIDA
    System.out.println("El grado farenheit convertido a Celsius es: "+CLS);
    
  }





  
}
  